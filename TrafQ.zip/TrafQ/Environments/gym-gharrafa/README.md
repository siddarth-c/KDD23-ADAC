# gym-gharrafa
#### **OpenAI Gym environment bundle for simulation of the Al Gharafa roundabout in Doha**

---

##Installation


Clone using
```bash
git clone https://github.com/qcri/TrafQ.git
```

After `cd Environments/gym-gharrafa`, install using
```bash
sudo pip3 install -e .
```

Example code in jupyter notebook.
